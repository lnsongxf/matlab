function [] = save_as_pdf(fighandler, filename)
    
    % SAVE FIGURE TO PDF WITH RIGHT SCALING
    %
    % Author:           Lukas Hoesch, Bjarni G. Einarsson
    % Last updated:     01/10/2019

    set(fighandler,'Units','Inches');
    pos = get(fighandler,'Position');
    set(fighandler, 'PaperPositionMode', 'Auto', ...
    'PaperUnits', 'Inches', 'PaperSize', [pos(3), pos(4)]);
    print(fighandler, filename, '-dpdf', '-r0');
    
end